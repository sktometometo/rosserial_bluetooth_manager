var searchData=
[
  ['baudrate',['baudRate',['../class_ics_hard_serial_class.html#a1bb994dd57372ad8a311bfae212cc670',1,'IcsHardSerialClass']]],
  ['begin',['begin',['../class_ics_hard_serial_class.html#a329d8b4b8c5b635c926d750cf0995e03',1,'IcsHardSerialClass::begin()'],['../class_ics_hard_serial_class.html#ac760127655becf664b414818df4999f4',1,'IcsHardSerialClass::begin(long baudrate, int timeout)'],['../class_ics_hard_serial_class.html#a4b18593c7cb0c4c28e563515b697fed3',1,'IcsHardSerialClass::begin(HardwareSerial *serial, int enpin, long baudrate, int timeout)'],['../class_ics_soft_serial_class.html#a9f2d5e67d748426eda81c94806ee8601',1,'IcsSoftSerialClass::begin()'],['../class_ics_soft_serial_class.html#ac1b7d44c2181b333a1596ad958915773',1,'IcsSoftSerialClass::begin(long baudrate, int timeout)'],['../class_ics_soft_serial_class.html#a5a611006af314eb2de48db9dcf160fa3',1,'IcsSoftSerialClass::begin(KoCustomSoftSerial *serial, byte enpin, long baudrate, int timeout)']]]
];
