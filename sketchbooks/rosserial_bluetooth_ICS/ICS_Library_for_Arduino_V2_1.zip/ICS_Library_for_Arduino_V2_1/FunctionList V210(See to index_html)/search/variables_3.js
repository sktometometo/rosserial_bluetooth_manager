var searchData=
[
  ['g_5fbaudrate',['g_baudrate',['../class_ics_soft_serial_class.html#a05f152531a378a448261c8f61d975c53',1,'IcsSoftSerialClass']]],
  ['g_5fenpin',['g_enpin',['../class_ics_soft_serial_class.html#a75e666c1c65a620505396fb52eb7f9e5',1,'IcsSoftSerialClass']]],
  ['g_5ftimeout',['g_timeout',['../class_ics_soft_serial_class.html#a961693d6df8386ed3a1a457daca3e13f',1,'IcsSoftSerialClass']]]
];
