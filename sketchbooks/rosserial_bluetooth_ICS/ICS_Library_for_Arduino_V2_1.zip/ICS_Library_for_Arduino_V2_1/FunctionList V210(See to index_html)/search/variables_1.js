var searchData=
[
  ['baudrate',['baudRate',['../class_ics_hard_serial_class.html#a1bb994dd57372ad8a311bfae212cc670',1,'IcsHardSerialClass']]]
];
